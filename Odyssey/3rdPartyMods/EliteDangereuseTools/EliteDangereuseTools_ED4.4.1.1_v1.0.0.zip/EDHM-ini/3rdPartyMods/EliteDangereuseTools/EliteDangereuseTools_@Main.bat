@ECHO OFF
SETLOCAL ENABLEEXTENSIONS
SETLOCAL ENABLEDELAYEDEXPANSION
MODE CON: cols=80 lines=30
COLOR 0a

REM -------------------------------------------------------------------
REM **** ALL YOU NEED TO CHANGE ARE THE VARIABLES BELOW ***
REM 'MOD_Prefix' is the common prefix of the mod files.
REM 'MOD_Folder' is the folder containing the mod files.
REM -------------------------------------------------------------------
SET "MOD_Prefix=EliteDangereuseTools_"
SET "MOD_Folder=%~dp0"

TITLE EDHM %MOD_Prefix% Mod Uninstaller

ECHO ===================================================================
ECHO ********** EDHM %MOD_Prefix% Mod Uninstaller ***********************
ECHO ** This will un-install all files added by the '%MOD_Prefix% Mod' **
ECHO -------------------------------------------------------------------

IF "%~1" == "-silent" GOTO :uninstall

:choice
SET /P c=Would you like to Proceed?:[Y/N]
IF /I "%c%" EQU "Y" GOTO :uninstall
IF /I "%c%" EQU "N" GOTO :thehell
GOTO :choice

REM -------------------------------------------------------------------
:uninstall
ECHO Removing files...

REM Remove all mod files matching the prefix
DEL /Q "%MOD_Folder%%MOD_Prefix%*.ini" 2>nul
DEL /Q "%MOD_Folder%%MOD_Prefix%*.json" 2>nul
DEL /Q "%MOD_Folder%%MOD_Prefix%*.png" 2>nul

REM Remove the assets folder
IF EXIST "%MOD_Folder%assets\" RMDIR /S /Q "%MOD_Folder%assets"

ECHO Uninstall Complete.

IF NOT "%~1" == "-silent" PAUSE

REM Finally the BAT self-destructs
GOTO 2>nul & DEL "%~f0" & cmd /c exit /b 10

:thehell
ECHO -------------------------------------------------------------------
EXIT /B %ERRORLEVEL%