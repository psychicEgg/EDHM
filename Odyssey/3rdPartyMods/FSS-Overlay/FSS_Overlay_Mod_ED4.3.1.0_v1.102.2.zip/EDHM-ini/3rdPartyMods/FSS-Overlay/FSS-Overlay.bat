@ECHO OFF
SETLOCAL ENABLEEXTENSIONS
SETLOCAL ENABLEDELAYEDEXPANSION
MODE CON: cols=80 lines=30
COLOR 0a
REM -------------------------------------------------------------------
REM **** ALL YOU NEED TO CHANGE IS THE 'MOD_Name' VARIABLE ***
REM 'MOD_Name' must be the exact File Name (no extension) of your INI file.
REM All Mod files share the name, changing only the File's Extension.
REM -------------------------------------------------------------------
SET MOD_Name=FSS-Overlay

TITLE EDHM %MOD_Name% Mod Uninstaller
ECHO ===================================================================
ECHO ********** EDHM %MOD_Name% Mod Uninstaller ***********************
ECHO ** This will un-install all files added by the '%MOD_Name% Mod' **
ECHO -------------------------------------------------------------------
IF "%~1" == "-silent" GOTO :uninstall
:choice
set /P c=Would you like to Proceed?:[Y/N]
if /I "%c%" EQU "Y" goto :uninstall
if /I "%c%" EQU "N" goto :thehell
goto :choice
REM -------------------------------------------------------------------
:thehell
ECHO -------------------------------------------------------------------
EXIT %ERRORLEVEL%
REM -------------------------------------------------------------------

:uninstall
ECHO Removing files..

REM Remove ini files
DEL *.ini >nul 2>&1

REM Remove png files
DEL *.png >nul 2>&1

REM -----IF YOUR MOD ADDS SHADERS, HERE THEY CAN BE REMOVED------------
DEL ..\..\..\ShaderFixes\04fc7f00bade5b4a-ps.txt >nul 2>&1
DEL ..\..\..\ShaderFixes\1d5a317f0e831e9d-ps.txt >nul 2>&1
DEL ..\..\..\ShaderFixes\d6c6b9abdf104b6d-ps.txt >nul 2>&1
DEL ..\..\..\ShaderFixes\ea5390a2f20c2368-ps.txt >nul 2>&1

:: In order to delete the current dir we are running from (and all subdirs), none of them can be the
:: current working directory of any running process. Therefore, we are setting our own CWD to something
:: else, so it will be inherited by the below cmd.exe
cd /d %temp%

:: The countdown is there to allow this batch file to exit, so it can then be deleted safely.
set DelayedSelfDeleteCommand="timeout /t 2 >NUL && rmdir /s /q "%~dp0""

IF NOT "%~1" == "-silent" ECHO Uninstall Complete
IF NOT "%~1" == "-silent" PAUSE

:: Start a separate process (without waiting for it), to execute the command
start "" /b cmd.exe /C %DelayedSelfDeleteCommand%

:: Exit must be specified if this script is executed from a command prompt (to close the parent terminal)
EXIT 0