EEEEEEEEEEEEEEEEEEEEEEDDDDDDDDDDDDD      HHHHHHHHH     HHHHHHHHHMMMMMMMM               MMMMMMMM
E::::::::::::::::::::ED::::::::::::DDD   H:::::::H     H:::::::HM:::::::M             M:::::::M
E::::::::::::::::::::ED:::::::::::::::DD H:::::::H     H:::::::HM::::::::M           M::::::::M
EE::::::EEEEEEEEE::::EDDD:::::DDDDD:::::DHH::::::H     H::::::HHM:::::::::M         M:::::::::M
  E:::::E       EEEEEE  D:::::D    D:::::D H:::::H     H:::::H  M::::::::::M       M::::::::::M
  E:::::E               D:::::D     D:::::DH:::::H     H:::::H  M:::::::::::M     M:::::::::::M
  E::::::EEEEEEEEEE     D:::::D     D:::::DH::::::HHHHH::::::H  M:::::::M::::M   M::::M:::::::M
  E:::::::::::::::E     D:::::D     D:::::DH:::::::::::::::::H  M::::::M M::::M M::::M M::::::M
  E:::::::::::::::E     D:::::D     D:::::DH:::::::::::::::::H  M::::::M  M::::M::::M  M::::::M
  E::::::EEEEEEEEEE     D:::::D     D:::::DH::::::HHHHH::::::H  M::::::M   M:::::::M   M::::::M
  E:::::E               D:::::D     D:::::DH:::::H     H:::::H  M::::::M    M:::::M    M::::::M
  E:::::E       EEEEEE  D:::::D    D:::::D H:::::H     H:::::H  M::::::M     MMMMM     M::::::M
EE::::::EEEEEEEE:::::EDDD:::::DDDDD:::::DHH::::::H     H::::::HHM::::::M               M::::::M
E::::::::::::::::::::ED:::::::::::::::DD H:::::::H     H:::::::HM::::::M               M::::::M
E::::::::::::::::::::ED::::::::::::DDD   H:::::::H     H:::::::HM::::::M               M::::::M
EEEEEEEEEEEEEEEEEEEEEEDDDDDDDDDDDDD      HHHHHHHHH     HHHHHHHHHMMMMMMMM               MMMMMMMM

Elite Dangerous HUD Mod (EDHM) v1.41

Installation instructions are available at the following link:

https://github.com/psychicEgg/EDHM/tree/main/Releases/v1.4


Instructions were moved online so they can be more easily updated and distributed.


v1.41 Minor Update: Removed the lighting fix that turned off the coloured cabin lighting when in External Camera


If you require any assistance, please contact me via:
u/psychicEgg on reddit 
psychicEgg#9971 on Discord
GeorjCostanza on the Elite forums
